package com.simanto.twin

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Collects incoming chat notifications into the Twin inbox. Nothing is sent anywhere from here. */
class TwinNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (!Apps.isChat(pkg)) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim() ?: return
        if (title.isEmpty() || text.isEmpty()) return

        val app = Apps.label(pkg)
        if (title.equals(app, ignoreCase = true)) return
        if (n.category == Notification.CATEGORY_SERVICE || n.category == Notification.CATEGORY_PROGRESS) return

        InboxStore.add(applicationContext, InboxItem(title, app, text, System.currentTimeMillis(), pkg))
    }
}
