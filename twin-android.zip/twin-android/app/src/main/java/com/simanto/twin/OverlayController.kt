package com.simanto.twin

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.Animatable2
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.Property
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * The floating Twin bubble (your eyes-sphere) and the popup with the live message + draft.
 * Windows are added through the accessibility service, so they sit above WhatsApp etc.
 */
class OverlayController(private val svc: TwinAccessibilityService) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val imm = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    private val handler = Handler(Looper.getMainLooper())

    private val bubbleW = dpi(64)
    private val bubbleH = (dpi(64) * 442f / 360f).toInt()
    private val pad = dpi(5)

    // ----- bubble -----
    private var bubbleRoot: FrameLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bubbleImg: ImageView? = null
    private var idleD: AnimatedImageDrawable? = null
    private var tapD: AnimatedImageDrawable? = null
    private val bobs = ArrayList<Animator>()

    // ----- popup -----
    private var popupRoot: LinearLayout? = null
    private var popupLp: WindowManager.LayoutParams? = null
    private var tvName: TextView? = null
    private var tvSub: TextView? = null
    private var tvMsg: TextView? = null
    private var etDraft: EditText? = null
    private var chips: List<TextView> = emptyList()
    private var mood = "Chill"
    private var gen = 0
    private var lastSnap: Snapshot? = null
    private var lastIncoming = ""
    private var lastContact = ""

    val popupOpen: Boolean
        get() = popupRoot != null

    // =====================================================================
    // Bubble
    // =====================================================================

    private fun decode(name: String): AnimatedImageDrawable? {
        return try {
            val src = ImageDecoder.createSource(svc.assets, name)
            val d = ImageDecoder.decodeDrawable(src) { decoder, _, _ ->
                decoder.setTargetSize(bubbleW, bubbleH)
            }
            d as? AnimatedImageDrawable
        } catch (e: Exception) {
            null
        }
    }

    fun showBubble() {
        if (bubbleRoot != null) return
        if (!Settings.canDrawOverlays(svc)) return

        val root = FrameLayout(svc)
        val img = ImageView(svc)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(img, FrameLayout.LayoutParams(bubbleW, bubbleH, Gravity.CENTER))

        val idle = decode("twin_idle.webp")
        val tap = decode("twin_tap.webp")
        idleD = idle
        tapD = tap
        if (idle != null) {
            idle.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            img.setImageDrawable(idle)
            idle.start()
        } else {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Color.parseColor("#101826"))
            g.setStroke(dpi(2), Color.parseColor("#6C8CFF"))
            img.setImageDrawable(g)
        }

        val lp = WindowManager.LayoutParams(
            bubbleW + 2 * pad,
            bubbleH + 2 * pad,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val dm = svc.resources.displayMetrics
        lp.x = dm.widthPixels - lp.width
        lp.y = Prefs.bubbleY(svc, (dm.heightPixels * 0.42f).toInt())

        attachDrag(root, lp)

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            idle?.stop()
            idleD = null
            tapD = null
            return
        }
        bubbleRoot = root
        bubbleLp = lp
        bubbleImg = img

        root.alpha = 0f
        root.scaleX = 0.6f
        root.scaleY = 0.6f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
        startBob(img)
    }

    fun hideAll() {
        hideBubble()
    }

    private fun hideBubble() {
        closePopup(false)
        val r = bubbleRoot ?: return
        for (a in bobs) a.cancel()
        bobs.clear()
        idleD?.stop()
        tapD?.stop()
        try {
            wm.removeView(r)
        } catch (e: Exception) {
        }
        bubbleRoot = null
        bubbleLp = null
        bubbleImg = null
        idleD = null
        tapD = null
    }

    fun destroy() {
        hideBubble()
    }

    private fun startBob(v: View) {
        fun mk(prop: Property<View, Float>, a: Float, b: Float, dur: Long) {
            val an = ObjectAnimator.ofFloat(v, prop, a, b)
            an.duration = dur
            an.repeatMode = ValueAnimator.REVERSE
            an.repeatCount = ValueAnimator.INFINITE
            an.interpolator = AccelerateDecelerateInterpolator()
            an.start()
            bobs.add(an)
        }
        mk(View.TRANSLATION_Y, -dp(3f), dp(3f), 2400L)
        mk(View.TRANSLATION_X, -dp(2f), dp(2f), 3100L)
        mk(View.ROTATION, -2f, 2f, 3700L)
    }

    private fun attachDrag(root: View, lp: WindowManager.LayoutParams) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > dp(8f)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        try {
                            wm.updateViewLayout(root, lp)
                        } catch (ex: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleTap() else snapToEdge(root, lp)
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToEdge(root: View, lp: WindowManager.LayoutParams) {
        val sw = svc.resources.displayMetrics.widthPixels
        val target = if (lp.x + lp.width / 2 < sw / 2) 0 else sw - lp.width
        Prefs.setBubbleY(svc, lp.y)
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 180
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(root, lp)
            } catch (e: Exception) {
            }
        }
        a.start()
    }

    private fun onBubbleTap() {
        if (popupRoot != null) {
            closePopup(true)
        } else {
            playSparks()
            openPopup()
        }
    }

    /** The spark animation: only when the popup is opened or closed by tapping. */
    private fun playSparks() {
        val img = bubbleImg ?: return
        val tap = tapD ?: return
        if (tap.isRunning) return
        tap.clearAnimationCallbacks()
        tap.registerAnimationCallback(object : Animatable2.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                val i = bubbleImg ?: return
                val idl = idleD ?: return
                i.setImageDrawable(idl)
                idl.start()
            }
        })
        tap.repeatCount = 0
        img.setImageDrawable(tap)
        tap.start()
    }

    // =====================================================================
    // Popup
    // =====================================================================

    private fun statusBarH(): Int {
        val id = svc.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) svc.resources.getDimensionPixelSize(id) else dpi(24)
    }

    private fun openPopup() {
        if (popupRoot != null) return
        val sw = svc.resources.displayMetrics.widthPixels

        val root = LinearLayout(svc)
        root.orientation = LinearLayout.VERTICAL
        root.background = GlassDrawable(dp(28f), 228)
        root.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))

        // header: name + sub, close button
        val header = LinearLayout(svc)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(svc)
        col.orientation = LinearLayout.VERTICAL
        val name = tv(svc, "Twin", 20f, UI.TEXT, serif = true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val sub = tv(svc, "live", 12f, UI.MUTED)
        col.addView(name)
        col.addView(sub)
        header.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = tv(svc, "\u2715", 15f, UI.TEXT)
        close.gravity = Gravity.CENTER
        close.background = GlassDrawable(dp(17f), 90)
        close.setOnClickListener {
            makeFocusable(false)
            closePopup(true)
        }
        header.addView(close, LinearLayout.LayoutParams(dpi(34), dpi(34)))
        root.addView(header)

        // incoming message
        val msg = tv(svc, "", 15f, UI.TEXT)
        msg.background = solid(Color.argb(70, 0, 0, 0), dp(16f))
        msg.setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
        msg.maxLines = 5
        msg.ellipsize = TextUtils.TruncateAt.END
        val msgLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        msgLp.topMargin = dpi(10)
        root.addView(msg, msgLp)

        // mood chips
        val chipRow = LinearLayout(svc)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val chipViews = ArrayList<TextView>()
        for (m in listOf("Chill", "Busy", "Soft")) {
            val c = tv(svc, m, 13f, UI.TEXT)
            c.gravity = Gravity.CENTER
            c.setPadding(0, dpi(9), 0, dpi(9))
            c.setOnClickListener {
                mood = m
                styleChips()
                makeFocusable(false)
                regenerate()
            }
            val clp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            clp.setMargins(dpi(3), 0, dpi(3), 0)
            chipRow.addView(c, clp)
            chipViews.add(c)
        }
        chips = chipViews
        val chipRowLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        chipRowLp.topMargin = dpi(10)
        root.addView(chipRow, chipRowLp)

        // draft
        val lbl = tv(svc, "TWIN DRAFT", 11f, UI.MUTED)
        lbl.letterSpacing = 0.12f
        val lblLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lblLp.topMargin = dpi(12)
        root.addView(lbl, lblLp)

        val et = EditText(svc)
        et.setTextColor(UI.TEXT)
        et.setHintTextColor(UI.MUTED)
        et.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
        et.background = solid(Color.argb(80, 0, 0, 0), dp(16f))
        et.setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
        et.minLines = 2
        et.maxLines = 5
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) makeFocusable(true)
            false
        }
        val etLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        etLp.topMargin = dpi(6)
        root.addView(et, etLp)

        // buttons
        val btnRow = LinearLayout(svc)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER_VERTICAL
        val regen = tv(svc, "\u21BB", 20f, UI.TEXT)
        regen.gravity = Gravity.CENTER
        regen.background = GlassDrawable(dp(23f), 90)
        regen.setOnClickListener {
            makeFocusable(false)
            regenerate()
        }
        btnRow.addView(regen, LinearLayout.LayoutParams(dpi(46), dpi(46)))

        val engine = tv(svc, "Gemini", 13f, UI.MUTED)
        engine.gravity = Gravity.CENTER
        engine.setPadding(dpi(16), 0, dpi(16), 0)
        engine.background = GlassDrawable(dp(23f), 70)
        val engLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dpi(46))
        engLp.setMargins(dpi(8), 0, dpi(8), 0)
        btnRow.addView(engine, engLp)

        val send = tv(svc, "Send", 15f, UI.SAGE_DARK, bold = true)
        send.gravity = Gravity.CENTER
        send.background = solid(UI.SAGE, dp(23f))
        send.setOnClickListener { onSendTapped() }
        btnRow.addView(send, LinearLayout.LayoutParams(0, dpi(46), 1f))

        val btnLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        btnLp.topMargin = dpi(12)
        root.addView(btnRow, btnLp)

        val lp = WindowManager.LayoutParams(
            sw - dpi(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = statusBarH() + dpi(6)

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        popupRoot = root
        popupLp = lp
        tvName = name
        tvSub = sub
        tvMsg = msg
        etDraft = et
        styleChips()

        root.alpha = 0f
        root.translationY = -dp(12f)
        root.animate().alpha(1f).translationY(0f).setDuration(200).start()

        val s = svc.currentSnapshot()
        lastSnap = s
        applySnapshot(s, true)
    }

    fun closePopup(sparks: Boolean) {
        val r = popupRoot ?: return
        gen++
        try {
            imm.hideSoftInputFromWindow(r.windowToken, 0)
        } catch (e: Exception) {
        }
        try {
            wm.removeView(r)
        } catch (e: Exception) {
        }
        popupRoot = null
        popupLp = null
        tvName = null
        tvSub = null
        tvMsg = null
        etDraft = null
        if (sparks) playSparks()
    }

    private fun styleChips() {
        for (c in chips) {
            if (c.text.toString() == mood) {
                c.background = solid(UI.SAGE, dp(20f))
                c.setTextColor(UI.SAGE_DARK)
            } else {
                c.background = GlassDrawable(dp(20f), 70)
                c.setTextColor(UI.TEXT)
            }
        }
    }

    /** Only while you type in the draft box does the popup take keyboard focus. */
    private fun makeFocusable(on: Boolean) {
        val lp = popupLp ?: return
        val root = popupRoot ?: return
        val et = etDraft
        if (on) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        try {
            wm.updateViewLayout(root, lp)
        } catch (e: Exception) {
        }
        if (on && et != null) {
            handler.postDelayed({
                et.requestFocus()
                imm.showSoftInput(et, 0)
            }, 220)
        } else if (et != null) {
            et.clearFocus()
            try {
                imm.hideSoftInputFromWindow(root.windowToken, 0)
            } catch (e: Exception) {
            }
        }
    }

    fun onSnapshot(s: Snapshot) {
        lastSnap = s
        if (popupRoot != null) applySnapshot(s, false)
    }

    private fun applySnapshot(s: Snapshot?, force: Boolean) {
        val incoming = if (s != null && s.inChat) s.latestIncoming else ""
        val contact = if (s != null && s.inChat) s.contact else ""
        tvName?.text = if (contact.isNotEmpty()) contact else "Twin"
        val app = if (s != null) Apps.label(s.pkg) else ""
        tvSub?.text = if (app.isNotEmpty()) app + " \u00B7 live" else "live"
        tvMsg?.text = if (incoming.isNotEmpty()) incoming else "Open a chat \u2014 the latest message shows up here."
        if (incoming.isEmpty()) {
            gen++
            etDraft?.setText("")
            etDraft?.hint = ""
            return
        }
        if (force || incoming != lastIncoming || contact != lastContact) {
            lastIncoming = incoming
            lastContact = contact
            regenerate()
        }
    }

    private fun regenerate() {
        val s = lastSnap ?: return
        if (!s.inChat || s.latestIncoming.isEmpty()) return
        val id = ++gen
        etDraft?.setText("")
        etDraft?.hint = "Twin is writing\u2026"
        GeminiClient.draft(svc, s, mood) { text, err ->
            if (id == gen && popupRoot != null) {
                val et = etDraft
                if (et != null) {
                    if (text != null) {
                        et.setText(text)
                        et.setSelection(et.text.length)
                        et.hint = ""
                    } else {
                        et.hint = err ?: "Couldn't write a draft"
                    }
                }
            }
        }
    }

    private fun onSendTapped() {
        val text = etDraft?.text?.toString()?.trim() ?: ""
        if (text.isEmpty()) return
        makeFocusable(false)
        handler.postDelayed({
            svc.sendReply(text) { ok ->
                if (ok) {
                    closePopup(true)
                } else {
                    Toast.makeText(
                        svc,
                        "I couldn't press Send. Your reply is copied \u2014 paste it and tap Send.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }, 150)
    }
}
