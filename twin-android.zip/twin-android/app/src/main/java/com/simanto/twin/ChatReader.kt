package com.simanto.twin

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

data class Msg(val text: String, val incoming: Boolean)

data class Snapshot(
    val pkg: String,
    val contact: String,
    val messages: List<Msg>,
    val inChat: Boolean
) {
    /** The newest message(s) from the other person (up to 3 in a row, after my last reply). */
    val latestIncoming: String
        get() {
            var i = messages.size - 1
            while (i >= 0 && !messages[i].incoming) i--
            if (i < 0) return ""
            val parts = ArrayList<String>()
            while (i >= 0 && messages[i].incoming && parts.size < 3) {
                parts.add(0, messages[i].text)
                i--
            }
            return parts.joinToString("\n")
        }
}

/**
 * Reads the visible chat screen through the accessibility tree.
 * WhatsApp is read by its known view ids; other apps use a generic layout heuristic
 * (text on the left = incoming, text on the right = my own message).
 */
object ChatReader {
    private class Item(val text: String, val b: Rect, val id: String)

    private val timeRe = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[AaPp]\\.?[Mm]\\.?)?$")
    private val skip = setOf(
        "online", "typing...", "typing…", "today", "yesterday", "type a message", "message",
        "you", "seen", "delivered", "active now", "last seen today", "call", "video call"
    )

    fun read(root: AccessibilityNodeInfo, screenW: Int, screenH: Int): Snapshot? {
        val pkg = root.packageName?.toString() ?: return null
        val items = ArrayList<Item>()
        val inputs = ArrayList<Rect>()
        walk(root, items, inputs, 0, IntArray(1))

        var inputTop = Int.MAX_VALUE
        for (r in inputs) {
            if (r.top > screenH * 0.55f && r.top < inputTop) inputTop = r.top
        }
        if (inputTop == Int.MAX_VALUE) return Snapshot(pkg, "", emptyList(), false)

        var contact = ""
        for (item in items) {
            if (item.id.endsWith(":id/conversation_contact_name")) {
                contact = item.text
                break
            }
        }
        if (contact.isEmpty()) {
            var best: Item? = null
            for (item in items) {
                if (item.b.bottom > screenH * 0.2f) continue
                if (timeRe.matches(item.text) || skip.contains(item.text.lowercase())) continue
                val cur = best
                if (cur == null || item.b.top < cur.b.top || (item.b.top == cur.b.top && item.b.left < cur.b.left)) {
                    best = item
                }
            }
            contact = best?.text ?: ""
        }

        val idMsgs = items.filter { it.id.endsWith(":id/message_text") }
        val cands: List<Item> = if (idMsgs.isNotEmpty()) {
            idMsgs
        } else {
            items.filter { item ->
                item.b.top > screenH * 0.12f &&
                    item.b.bottom < inputTop &&
                    !timeRe.matches(item.text) &&
                    !skip.contains(item.text.lowercase()) &&
                    item.text != contact
            }
        }
        val sorted = cands.sortedWith(compareBy<Item>({ it.b.top }, { it.b.left }))

        val msgs = ArrayList<Msg>()
        for (item in sorted) {
            val leftGap = item.b.left
            val rightGap = screenW - item.b.right
            // perfectly centred text = date labels / system notices, not a message
            if (Math.abs(leftGap - rightGap) < screenW * 0.02f) continue
            msgs.add(Msg(item.text, leftGap < rightGap))
        }
        val last: List<Msg> = if (msgs.size > 10) msgs.subList(msgs.size - 10, msgs.size) else msgs
        return Snapshot(pkg, contact, ArrayList(last), true)
    }

    private fun walk(
        n: AccessibilityNodeInfo?,
        out: ArrayList<Item>,
        inputs: ArrayList<Rect>,
        depth: Int,
        counter: IntArray
    ) {
        if (n == null || depth > 45 || counter[0] > 1500) return
        counter[0]++
        if (!n.isVisibleToUser) return
        val r = Rect()
        n.getBoundsInScreen(r)
        if (n.isEditable) {
            inputs.add(r)
        } else {
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty()) out.add(Item(t, r, n.viewIdResourceName ?: ""))
        }
        for (i in 0 until n.childCount) {
            walk(n.getChild(i), out, inputs, depth + 1, counter)
        }
    }
}
