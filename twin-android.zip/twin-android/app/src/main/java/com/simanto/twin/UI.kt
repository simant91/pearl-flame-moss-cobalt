package com.simanto.twin

import android.content.Context
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.widget.TextView

object UI {
    val BG: Int = Color.parseColor("#0A0E0D")
    val TEXT: Int = Color.parseColor("#ECEFEA")
    val MUTED: Int = Color.parseColor("#8E9892")
    val SAGE: Int = Color.parseColor("#C9D5C6")
    val SAGE_DARK: Int = Color.parseColor("#10150F")
}

fun dp(v: Float): Float = v * Resources.getSystem().displayMetrics.density

fun dpi(v: Int): Int = (v * Resources.getSystem().displayMetrics.density + 0.5f).toInt()

fun solid(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

fun tv(
    ctx: Context,
    text: String,
    sp: Float,
    color: Int,
    serif: Boolean = false,
    bold: Boolean = false,
    italic: Boolean = false
): TextView {
    val t = TextView(ctx)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    var style = Typeface.NORMAL
    if (bold && italic) style = Typeface.BOLD_ITALIC
    else if (bold) style = Typeface.BOLD
    else if (italic) style = Typeface.ITALIC
    if (serif) {
        t.typeface = Typeface.create(Typeface.SERIF, style)
    } else if (style != Typeface.NORMAL) {
        t.typeface = Typeface.create(Typeface.DEFAULT, style)
    }
    return t
}

/**
 * "Liquid glass" look: a dark translucent body, a soft white sheen that fades
 * down the surface, and a thin edge light that is bright at the top-left and
 * bottom-right corners (like light catching the rim of real glass).
 */
class GlassDrawable(private val radius: Float, private val baseAlpha: Int = 140) : Drawable() {
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        rimPaint.style = Paint.Style.STROKE
        rimPaint.strokeWidth = dp(1.2f)
    }

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val inset = rimPaint.strokeWidth / 2f
        rect.set(
            bounds.left + inset,
            bounds.top + inset,
            bounds.right - inset,
            bounds.bottom - inset
        )
        basePaint.color = Color.argb(baseAlpha, 16, 22, 20)
        sheenPaint.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(
                Color.argb(54, 255, 255, 255),
                Color.argb(12, 255, 255, 255),
                Color.argb(32, 190, 215, 255)
            ),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        rimPaint.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(
                Color.argb(175, 255, 255, 255),
                Color.argb(26, 255, 255, 255),
                Color.argb(115, 200, 225, 255)
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        val r = minOf(radius, rect.height() / 2f, rect.width() / 2f)
        canvas.drawRoundRect(rect, r, r, basePaint)
        canvas.drawRoundRect(rect, r, r, sheenPaint)
        canvas.drawRoundRect(rect, r, r, rimPaint)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Dark page background with soft colour glows (teal, violet, rose) rising from the bottom. */
class GlowBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        canvas.drawColor(UI.BG)
        glow(canvas, w, h, w * 0.18f, h * 0.95f, w * 0.80f, Color.argb(80, 70, 190, 210))
        glow(canvas, w, h, w * 0.90f, h * 0.82f, w * 0.75f, Color.argb(70, 150, 100, 230))
        glow(canvas, w, h, w * 0.50f, h * 1.02f, w * 0.95f, Color.argb(36, 225, 120, 165))
    }

    private fun glow(c: Canvas, w: Float, h: Float, x: Float, y: Float, r: Float, color: Int) {
        p.shader = RadialGradient(x, y, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
