package com.simanto.twin

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object GeminiClient {
    private val exec = Executors.newCachedThreadPool()
    private val main = Handler(Looper.getMainLooper())

    // Tried in this order when the saved model name is empty or not found.
    private val FALLBACK = listOf(
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite",
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite"
    )

    private class Res(val text: String?, val code: Int, val err: String)

    /** Calls back on the main thread: (draftText, errorMessage). */
    fun draft(ctx: Context, snap: Snapshot, mood: String, cb: (String?, String?) -> Unit) {
        val app = ctx.applicationContext
        exec.execute {
            var text: String? = null
            var err: String? = null
            try {
                text = request(app, snap, mood)
            } catch (e: Exception) {
                err = e.message ?: "Something went wrong"
            }
            main.post { cb(text, err) }
        }
    }

    private fun request(ctx: Context, snap: Snapshot, mood: String): String {
        val key = Prefs.apiKey(ctx)
        if (key.isEmpty()) throw Exception("Add your Gemini API key in Twin > Vault")
        val system = buildSystem(ctx, mood)
        val user = buildUser(snap)

        val models = LinkedHashSet<String>()
        val saved = Prefs.model(ctx)
        if (saved.isNotEmpty()) models.add(saved)
        models.addAll(FALLBACK)

        var lastErr = "Model not found. Check the model name in Vault."
        for (m in models) {
            val r = call(key, m, system, user)
            if (r.text != null) {
                if (m != saved) Prefs.setModel(ctx, m)
                return clean(r.text)
            }
            when {
                r.code == 404 -> lastErr = r.err
                r.code == 429 -> throw Exception("Gemini limit reached. Try again in a minute.")
                r.code == 400 && r.err.contains("API key", ignoreCase = true) ->
                    throw Exception("Gemini API key is not valid.")
                r.code == 403 -> throw Exception("Gemini key not allowed: " + r.err)
                else -> throw Exception(r.err)
            }
        }
        throw Exception(lastErr)
    }

    private fun clean(s: String): String {
        var t = s.trim()
        if (t.startsWith("Me:")) t = t.removePrefix("Me:").trim()
        if (t.length >= 2 && t.startsWith("\"") && t.endsWith("\"")) t = t.substring(1, t.length - 1)
        return t.trim()
    }

    private fun buildSystem(ctx: Context, mood: String): String {
        val name = Prefs.userName(ctx)
        val samples = Prefs.samples(ctx).trim()
        val moodText = when (mood) {
            "Busy" -> "Mood: BUSY. Very short. Say you are busy right now and will reply later, unless the message needs nothing more."
            "Soft" -> "Mood: SOFT. Warm, caring and gentle."
            else -> "Mood: CHILL. Relaxed, friendly, casual."
        }
        val sb = StringBuilder()
        sb.append("You write the reply that ").append(name).append(" would send, in his exact voice.\n")
        sb.append("Reply in the same language and script as the latest incoming message: ")
        sb.append("Bengali script gets a Bengali-script reply; Bangla typed in English letters (Banglish) gets Banglish with similar spelling; English gets English.\n")
        sb.append("Keep it short and natural like a real chat text (usually 2 to 15 words). ")
        sb.append("No emojis unless the style examples use them. No quotes, no explanations. Never say you are an AI.\n")
        sb.append(moodText).append("\n")
        if (samples.isNotEmpty()) {
            sb.append("\nExamples of how ").append(name)
                .append(" really texts (copy this style, spelling and slang):\n").append(samples).append("\n")
        }
        sb.append("\nOutput ONLY the reply text.")
        return sb.toString()
    }

    private fun buildUser(snap: Snapshot): String {
        val who = if (snap.contact.isNotEmpty()) snap.contact else "them"
        val recent = if (snap.messages.size > 8) snap.messages.subList(snap.messages.size - 8, snap.messages.size) else snap.messages
        val lines = StringBuilder()
        for (m in recent) {
            lines.append(if (m.incoming) who else "Me").append(": ").append(m.text).append("\n")
        }
        return "Chat with " + who + " on " + Apps.label(snap.pkg) + ".\n" +
            "Recent messages:\n" + lines.toString() + "\n" +
            "Write my reply to the latest message(s) from " + who + ":\n" + snap.latestIncoming
    }

    private fun call(key: String, model: String, system: String, user: String): Res {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)

            val body = JSONObject()
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            body.put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))
                )
            )
            body.put(
                "generationConfig",
                JSONObject().put("temperature", 0.9).put("maxOutputTokens", 1024)
            )
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                var msg = "HTTP " + code
                try {
                    msg = JSONObject(raw).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                }
                return Res(null, code, msg)
            }

            val j = JSONObject(raw)
            val sb = StringBuilder()
            val cands = j.optJSONArray("candidates")
            if (cands != null && cands.length() > 0) {
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val p = parts.getJSONObject(i)
                        if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
                    }
                }
            }
            val t = sb.toString().trim()
            return if (t.isEmpty()) Res(null, 200, "Gemini returned an empty reply") else Res(t, 200, "")
        } finally {
            c.disconnect()
        }
    }
}
