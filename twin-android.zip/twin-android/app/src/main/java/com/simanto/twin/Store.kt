package com.simanto.twin

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

object Apps {
    private val labels = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp",
        "com.instagram.android" to "Instagram",
        "com.facebook.orca" to "Messenger",
        "com.facebook.mlite" to "Messenger"
    )

    fun isChat(pkg: String?): Boolean = pkg != null && labels.containsKey(pkg)

    fun label(pkg: String?): String {
        if (pkg == null) return ""
        return labels[pkg] ?: ""
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("twin_prefs", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) { sp(c).edit().putString("api_key", v.trim()).apply() }

    fun model(c: Context): String = sp(c).getString("model", "") ?: ""
    fun setModel(c: Context, v: String) { sp(c).edit().putString("model", v.trim()).apply() }

    fun userName(c: Context): String = sp(c).getString("name", "Simanto") ?: "Simanto"
    fun setUserName(c: Context, v: String) { sp(c).edit().putString("name", v.trim()).apply() }

    fun samples(c: Context): String = sp(c).getString("samples", "") ?: ""
    fun setSamples(c: Context, v: String) { sp(c).edit().putString("samples", v.trim()).apply() }

    fun bubbleY(c: Context, def: Int): Int = sp(c).getInt("bubble_y", def)
    fun setBubbleY(c: Context, v: Int) { sp(c).edit().putInt("bubble_y", v).apply() }
}

data class InboxItem(
    val sender: String,
    val app: String,
    val text: String,
    val time: Long,
    val pkg: String
)

object InboxStore {
    private val items = ArrayList<InboxItem>()
    private val listeners = ArrayList<Runnable>()
    private var loaded = false
    private val main = Handler(Looper.getMainLooper())

    @Synchronized
    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        try {
            val raw = c.getSharedPreferences("twin_inbox", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(
                    InboxItem(
                        o.optString("s"),
                        o.optString("a"),
                        o.optString("t"),
                        o.optLong("ts"),
                        o.optString("p")
                    )
                )
            }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun all(c: Context): List<InboxItem> {
        load(c)
        return ArrayList(items)
    }

    @Synchronized
    fun add(c: Context, item: InboxItem) {
        load(c)
        if (items.isNotEmpty() && items[0].sender == item.sender && items[0].text == item.text) return
        items.add(0, item)
        while (items.size > 40) items.removeAt(items.size - 1)
        val arr = JSONArray()
        for (x in items) {
            val o = JSONObject()
            o.put("s", x.sender)
            o.put("a", x.app)
            o.put("t", x.text)
            o.put("ts", x.time)
            o.put("p", x.pkg)
            arr.put(o)
        }
        c.getSharedPreferences("twin_inbox", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
        notifyChanged()
    }

    @Synchronized
    fun addListener(r: Runnable) {
        listeners.add(r)
    }

    @Synchronized
    fun removeListener(r: Runnable) {
        listeners.remove(r)
    }

    private fun notifyChanged() {
        val copy = ArrayList(listeners)
        main.post {
            for (r in copy) r.run()
        }
    }
}
