package com.simanto.twin

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var setupBox: LinearLayout
    private lateinit var body: LinearLayout
    private var tabViews: List<TextView> = emptyList()
    private var tab = 0
    private val inboxListener = Runnable { if (tab == 0) renderBody() }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(GlowBackground())

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dpi(20), dpi(22), dpi(20), dpi(40))
        scroll.addView(page, ViewGroup.LayoutParams(MATCH, WRAP))
        setContentView(scroll)

        val title = tv(this, "Twin", 42f, UI.TEXT, serif = true, italic = true)
        page.addView(title)
        val subtitle = tv(this, "Your messaging twin \u00B7 on this phone", 13f, UI.MUTED)
        page.addView(subtitle)

        setupBox = LinearLayout(this)
        setupBox.orientation = LinearLayout.VERTICAL
        setupBox.background = GlassDrawable(dp(24f), 120)
        setupBox.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        val setupLp = LinearLayout.LayoutParams(MATCH, WRAP)
        setupLp.topMargin = dpi(18)
        page.addView(setupBox, setupLp)

        // tab bar
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = GlassDrawable(dp(26f), 110)
        bar.setPadding(dpi(5), dpi(5), dpi(5), dpi(5))
        val names = listOf("Inbox", "Voice", "Route", "Vault")
        val views = ArrayList<TextView>()
        for (i in names.indices) {
            val t = tv(this, names[i], 14f, UI.TEXT)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dpi(10), 0, dpi(10))
            t.setOnClickListener {
                tab = i
                styleTabs()
                renderBody()
            }
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            views.add(t)
        }
        tabViews = views
        val barLp = LinearLayout.LayoutParams(MATCH, WRAP)
        barLp.topMargin = dpi(16)
        page.addView(bar, barLp)

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val bodyLp = LinearLayout.LayoutParams(MATCH, WRAP)
        bodyLp.topMargin = dpi(18)
        page.addView(body, bodyLp)

        styleTabs()
        renderBody()
    }

    override fun onResume() {
        super.onResume()
        InboxStore.addListener(inboxListener)
        renderSetup()
        if (tab == 0) renderBody()
    }

    override fun onPause() {
        InboxStore.removeListener(inboxListener)
        super.onPause()
    }

    // ------------------------------------------------------------------ setup

    private fun listenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun renderSetup() {
        setupBox.removeAllViews()
        val a11y = TwinAccessibilityService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        val notif = listenerEnabled()
        val key = Prefs.apiKey(this).isNotEmpty()

        if (a11y && overlay && notif && key) {
            setupBox.addView(tv(this, "All set \u2713", 16f, UI.SAGE, serif = true, bold = true))
            val hint = tv(this, "Open WhatsApp, Instagram or Messenger \u2014 the Twin bubble appears there.", 13f, UI.MUTED)
            hint.setPadding(0, dpi(4), 0, 0)
            setupBox.addView(hint)
            return
        }

        setupBox.addView(tv(this, "Setup", 18f, UI.TEXT, serif = true))
        setupRow("Accessibility (reads the open chat)", a11y, "Open") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        setupRow("Show over other apps (the bubble)", overlay, "Open") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
            )
        }
        setupRow("Notification access (Inbox)", notif, "Open") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        setupRow("Gemini API key", key, "Add") {
            tab = 3
            styleTabs()
            renderBody()
        }
        if (!a11y || !notif) {
            val help = tv(
                this,
                "If Accessibility or Notification access is greyed out: open App info, tap the \u22EE menu, then \"Allow restricted settings\".",
                12f,
                UI.MUTED
            )
            help.setPadding(0, dpi(10), 0, 0)
            setupBox.addView(help)
            val btn = pill("Open App info", false) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
                )
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.topMargin = dpi(8)
            setupBox.addView(btn, lp)
        }
    }

    private fun setupRow(label: String, done: Boolean, action: String, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = solid(if (done) UI.SAGE else Color.parseColor("#D9776B"), dp(5f))
        row.addView(dot, LinearLayout.LayoutParams(dpi(10), dpi(10)))
        val t = tv(this, label, 14f, UI.TEXT)
        t.setPadding(dpi(10), 0, dpi(8), 0)
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (!done) {
            row.addView(pill(action, true) { onClick() }, LinearLayout.LayoutParams(WRAP, WRAP))
        } else {
            row.addView(tv(this, "On", 13f, UI.MUTED))
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dpi(10)
        setupBox.addView(row, lp)
    }

    private fun pill(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val t = tv(this, text, 13f, if (filled) UI.SAGE_DARK else UI.TEXT, bold = filled)
        t.gravity = Gravity.CENTER
        t.setPadding(dpi(16), dpi(8), dpi(16), dpi(8))
        t.background = if (filled) solid(UI.SAGE, dp(18f)) else GlassDrawable(dp(18f), 80)
        t.setOnClickListener { onClick() }
        return t
    }

    // ------------------------------------------------------------------ tabs

    private fun styleTabs() {
        for (i in tabViews.indices) {
            val t = tabViews[i]
            if (i == tab) {
                t.background = solid(UI.SAGE, dp(21f))
                t.setTextColor(UI.SAGE_DARK)
            } else {
                t.background = null
                t.setTextColor(UI.TEXT)
            }
        }
    }

    private fun renderBody() {
        body.removeAllViews()
        when (tab) {
            0 -> renderInbox()
            1 -> renderSoon("Voice", "Talk to your twin by voice. Coming in the next version.")
            2 -> renderSoon("Route", "Choose where drafts are written: this phone, your PC (Ollama) or the cloud. Right now every draft uses Gemini in the cloud.")
            else -> renderVault()
        }
    }

    private fun renderSoon(title: String, text: String) {
        body.addView(tv(this, title, 28f, UI.TEXT, serif = true))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = GlassDrawable(dp(22f), 110)
        card.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
        card.addView(tv(this, text, 14f, UI.MUTED))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dpi(12)
        body.addView(card, lp)
    }

    private fun renderInbox() {
        body.addView(tv(this, "Inbox", 28f, UI.TEXT, serif = true))
        val sub = tv(this, "Waiting on you. Drafts stay on this phone until you tap Send.", 13f, UI.MUTED)
        sub.setPadding(0, dpi(2), 0, dpi(6))
        body.addView(sub)

        val items = InboxStore.all(this)
        if (items.isEmpty()) {
            val card = LinearLayout(this)
            card.background = GlassDrawable(dp(22f), 110)
            card.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
            card.addView(
                tv(
                    this,
                    "No messages yet. When someone messages you on WhatsApp, Instagram or Messenger, it shows up here.",
                    14f,
                    UI.MUTED
                )
            )
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dpi(10)
            body.addView(card, lp)
            return
        }

        val now = System.currentTimeMillis()
        for (item in items) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.background = GlassDrawable(dp(22f), 110)
            card.setPadding(dpi(14), dpi(12), dpi(14), dpi(12))

            val initial = if (item.sender.isNotEmpty()) item.sender.substring(0, 1).uppercase() else "?"
            val av = tv(this, initial, 17f, UI.TEXT, serif = true)
            av.gravity = Gravity.CENTER
            av.background = solid(Color.parseColor("#2A332F"), dp(21f))
            card.addView(av, LinearLayout.LayoutParams(dpi(42), dpi(42)))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dpi(12), 0, dpi(8), 0)
            val head = LinearLayout(this)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(tv(this, item.sender, 15f, UI.TEXT, bold = true))
            val chip = tv(this, item.app, 11f, UI.SAGE)
            chip.setPadding(dpi(8), dpi(2), dpi(8), dpi(2))
            chip.background = GlassDrawable(dp(10f), 60)
            val chipLp = LinearLayout.LayoutParams(WRAP, WRAP)
            chipLp.leftMargin = dpi(8)
            head.addView(chip, chipLp)
            col.addView(head)
            val msg = tv(this, item.text, 14f, UI.MUTED)
            msg.maxLines = 2
            msg.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(msg)
            card.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

            val ago = DateUtils.getRelativeTimeSpanString(item.time, now, DateUtils.MINUTE_IN_MILLIS).toString()
            card.addView(tv(this, ago, 11f, UI.MUTED))

            card.setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage(item.pkg)
                if (i != null) startActivity(i)
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dpi(10)
            body.addView(card, lp)
        }
    }

    private fun field(hint: String, value: String, multiline: Boolean, password: Boolean): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.setTextColor(UI.TEXT)
        e.setHintTextColor(UI.MUTED)
        e.textSize = 15f
        e.background = solid(Color.argb(80, 0, 0, 0), dp(16f))
        e.setPadding(dpi(14), dpi(12), dpi(14), dpi(12))
        if (multiline) {
            e.minLines = 4
            e.gravity = Gravity.TOP or Gravity.START
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else if (password) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            e.inputType = InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun renderVault() {
        body.addView(tv(this, "Vault", 28f, UI.TEXT, serif = true))
        val sub = tv(
            this,
            "Your key and your texting style stay on this phone. Chat text is sent to Gemini only to write a draft.",
            13f,
            UI.MUTED
        )
        sub.setPadding(0, dpi(2), 0, dpi(6))
        body.addView(sub)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = GlassDrawable(dp(24f), 110)
        card.setPadding(dpi(16), dpi(16), dpi(16), dpi(16))

        fun label(t: String) {
            val l = tv(this, t, 12f, UI.MUTED)
            l.setPadding(0, dpi(12), 0, dpi(4))
            card.addView(l)
        }

        label("Gemini API key (from Google AI Studio)")
        val key = field("AIza...", Prefs.apiKey(this), false, true)
        card.addView(key, LinearLayout.LayoutParams(MATCH, WRAP))

        label("Model (leave empty = automatic)")
        val model = field("automatic", Prefs.model(this), false, false)
        card.addView(model, LinearLayout.LayoutParams(MATCH, WRAP))

        label("Your name")
        val name = field("Simanto", Prefs.userName(this), false, false)
        card.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))

        label("How you text \u2014 paste 10 to 20 of your real messages, one per line")
        val samples = field("kire kal cricket asbi?\nha ashar try korbo bro", Prefs.samples(this), true, false)
        card.addView(samples, LinearLayout.LayoutParams(MATCH, WRAP))

        val save = pill("Save", true) {
            Prefs.setApiKey(this, key.text.toString())
            Prefs.setModel(this, model.text.toString())
            val n = name.text.toString().trim()
            Prefs.setUserName(this, if (n.isEmpty()) "Simanto" else n)
            Prefs.setSamples(this, samples.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            renderSetup()
        }
        val saveLp = LinearLayout.LayoutParams(MATCH, WRAP)
        saveLp.topMargin = dpi(16)
        card.addView(save, saveLp)

        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dpi(10)
        body.addView(card, lp)
    }
}
