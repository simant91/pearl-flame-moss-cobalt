package com.simanto.twin

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * - Shows the Twin bubble only while WhatsApp / Instagram / Messenger is in front.
 * - Reads the open chat (only while the popup is open) so the popup stays live.
 * - Types the reply into the chat box and presses Send, only after YOU tap Send in the popup.
 */
class TwinAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TwinAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: OverlayController? = null
    private var evalPending = false
    private var readPending = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        overlay = OverlayController(this)
        scheduleEval()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        overlay?.destroy()
        overlay = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        overlay?.destroy()
        overlay = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val ov = overlay ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> scheduleEval()
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Content of other apps is never read: we only react while the popup is open in a chat app.
                if (ov.popupOpen && Apps.isChat(pkg)) scheduleRead()
            }
        }
    }

    private fun scheduleEval() {
        if (evalPending) return
        evalPending = true
        handler.postDelayed({
            evalPending = false
            evaluate()
        }, 200)
    }

    private fun evaluate() {
        val ov = overlay ?: return
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (Apps.isChat(pkg)) ov.showBubble() else ov.hideAll()
    }

    private fun scheduleRead() {
        if (readPending) return
        readPending = true
        handler.postDelayed({
            readPending = false
            val ov = overlay
            if (ov != null && ov.popupOpen) {
                val s = currentSnapshot()
                if (s != null) ov.onSnapshot(s)
            }
        }, 350)
    }

    private fun chatRoot(): AccessibilityNodeInfo? {
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    val r = w.root
                    if (r != null && Apps.isChat(r.packageName?.toString())) return r
                }
            }
        } catch (e: Exception) {
        }
        val r = rootInActiveWindow
        return if (r != null && Apps.isChat(r.packageName?.toString())) r else null
    }

    fun currentSnapshot(): Snapshot? {
        val root = chatRoot() ?: return null
        val dm = resources.displayMetrics
        return ChatReader.read(root, dm.widthPixels, dm.heightPixels)
    }

    // ---------- Send ----------

    fun sendReply(text: String, onDone: (Boolean) -> Unit) {
        val root = chatRoot()
        val input = if (root != null) findInput(root) else null
        if (input == null) {
            copyToClipboard(text)
            onDone(false)
            return
        }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        var ok = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) {
            copyToClipboard(text)
            ok = input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        if (!ok) {
            copyToClipboard(text)
            onDone(false)
            return
        }
        handler.postDelayed({
            val r2 = chatRoot()
            val btn = if (r2 != null) findSend(r2) else null
            var clicked = false
            if (btn != null) {
                var t: AccessibilityNodeInfo? = btn
                while (t != null && !t.isClickable) t = t.parent
                if (t != null) clicked = t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            if (!clicked) copyToClipboard(text)
            onDone(clicked)
        }, 450)
    }

    private fun copyToClipboard(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("twin", text))
        } catch (e: Exception) {
        }
    }

    private fun findInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val byId = find(root, 0) { it.isEditable && (it.viewIdResourceName ?: "").endsWith(":id/entry") }
        if (byId != null) return byId
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(root, 0, list) { it.isEditable }
        var best: AccessibilityNodeInfo? = null
        var bestTop = -1
        for (n in list) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top > bestTop) {
                bestTop = r.top
                best = n
            }
        }
        return best
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        return find(root, 0) { n ->
            val id = n.viewIdResourceName ?: ""
            val d = (n.contentDescription?.toString() ?: "").trim().lowercase()
            n.isEnabled && (
                id.endsWith(":id/send") ||
                    id.contains("button_send") ||
                    d == "send" ||
                    d == "send message" ||
                    d == "পাঠান"
                )
        }
    }

    private fun find(
        n: AccessibilityNodeInfo?,
        depth: Int,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (n == null || depth > 45) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val r = find(n.getChild(i), depth + 1, pred)
            if (r != null) return r
        }
        return null
    }

    private fun collect(
        n: AccessibilityNodeInfo?,
        depth: Int,
        out: ArrayList<AccessibilityNodeInfo>,
        pred: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (n == null || depth > 45) return
        if (pred(n)) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), depth + 1, out, pred)
    }
}
